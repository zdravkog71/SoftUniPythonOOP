from project.tomcat import Tomcat

t = Tomcat("Meowy", 20)
exp = "This is Meowy. Meowy is a 20 year old Male Tomcat"
print(repr(t))